﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace App2
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        int count = 0;
        void Button_Clicked(object sender, System.EventArgs e)
        {
            count++;
            ((Button)sender).Text = $"Clickeaste {count} veces.";
        }

        private async void Web_Clicked(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new Page1());
        }

        private async void Entry_Clicked(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new Entry1());
        }

        private async void usuario_Clicked(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new userPage());
        }
    }
}
