﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace App2
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class userPage : ContentPage
    {
        public userPage()
        {
            InitializeComponent();
        }

        public void Fin_Click(object sender, System.EventArgs e)
        {
            var sw = Activo.IsToggled;
            var swtext = "";
            if (sw is true)
            {
                 swtext= "Si";
            }
            else
            {
                swtext = "No";
            }
            var texto = "Nombre: " + Nombre.Text + "\nEmail: " + Email.Text + "\nTelefono: " + Telefono.Text + "\nContraseña: " + Contraseña.Text + "\nFecha Cumpleaños: " + Fecha.Date+ "\nEs usuario Activo?: "+swtext;
            DisplayAlert("Datos Usuario", texto, "Aceptar");
        }
        private async void Menu(object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new MainPage());
        }
    }
}